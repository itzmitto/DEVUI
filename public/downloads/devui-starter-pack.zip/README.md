DevUI Starter Pack

Kopieer de 2 componenten naar src/components/buttons. Ze gebruiken React, react-router-dom en Remix Icon (CDN).
